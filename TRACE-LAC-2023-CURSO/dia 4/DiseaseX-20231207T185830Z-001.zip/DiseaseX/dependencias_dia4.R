# Antes de instalar Rstan es necesario configurar C++ Toolchain. 
# Luego de haber configurado C++ Toolchain, ejecute el siguiente comando
# install.packages("rstan", repos = "https://cloud.r-project.org/", dependencies = TRUE) 

install.packages("dplyr")
install.packages("incidence")
install.packages("coarseDataTools")
install.packages("EpiEstim")
install.packages("ggplot2")
install.packages("loo")
install.packages("patchwork")
install.packages("parallel")

# Packages on GitHub
remotes::install_github("reconhub/epicontacts")


